package com.example.demo.handlers;

public class StudentHandler{
    public static String validateStudent(){

        /*TODO: logica para validar el estudiante*/

        return "it is ok";
    }

    public static String saveStudent(){
        /*TODO: logica para guardar el estudiante*/

        return "student saved successfully";
    }
}
