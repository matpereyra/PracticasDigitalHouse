public enum TipoMotor {
    DIESEL, BENCINA
}
